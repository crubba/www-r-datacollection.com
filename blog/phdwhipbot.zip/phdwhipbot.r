# phdwhipbot 0.1
# author: simon munzert

# load packages
library(stringr)
library(XML)
library(twitteR)
library(XLConnect)
library(ROAuth)

# load text bits
shoutings   <- readWorksheet(loadWorkbook("phdwhipbot-shoutings.xlsx"), sheet=1,header=F,simplify=T)
animals     <- readWorksheet(loadWorkbook("phdwhipbot-animals.xlsx"),   sheet=1,header=F,simplify=T)
attributs   <- readWorksheet(loadWorkbook("phdwhipbot-attributes.xlsx"),sheet=1,header=F,simplify=T)
  
# setup authentication
api_key <- Sys.getenv("phdbot_api_key")
api_secret <- Sys.getenv("phdbot_api_secret")
access_token <- Sys.getenv("phdbot_access_token")
access_token_secret <- Sys.getenv("phdbot_access_token_secret")
setup_twitter_oauth(api_key,api_secret,access_token,access_token_secret)

# generate tweet
tweettxt <- toupper(str_c(sample(shoutings, 1), " ", sample(attributs, 1), " ", sample(animals, 1), "."))

# send tweet
tweettxt
tweet(tweettxt)

# create log entry
line <- paste( as.character(Sys.time()), tweettxt,sep="\t" )
write(line, file="tweets.log", append=TRUE)

