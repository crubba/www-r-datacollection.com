$(document).ready(function() {
    $("body").load("quotes/quotes.html", function() {
	alert("Quotes.html was fetched.");
    });
});